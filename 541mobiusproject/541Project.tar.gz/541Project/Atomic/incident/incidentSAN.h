#ifndef incidentSAN_H_
#define incidentSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern double ArrivalRate;
extern short MaxQueueSize;
extern double CostPerLevel;
extern double DistributionSlope;
extern double DistributionIntercept;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               incidentSAN Submodel Definition                   
*********************************************************************/

class incidentSAN:public SANModel{
public:

class UpdateProcessingActivity:public Activity {
public:

  Place* QueueSize;
  short* QueueSize_Mobius_Mark;
  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateProcessingActivity();
  ~UpdateProcessingActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
 bool Process_GateIP();
}; // UpdateProcessingActivityActivity

class UpdateArrivalActivity_case1:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case1();
  ~UpdateArrivalActivity_case1();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case1Activity

class UpdateArrivalActivity_case2:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case2();
  ~UpdateArrivalActivity_case2();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case2Activity

class UpdateArrivalActivity_case3:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case3();
  ~UpdateArrivalActivity_case3();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case3Activity

class UpdateArrivalActivity_case4:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case4();
  ~UpdateArrivalActivity_case4();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case4Activity

class UpdateArrivalActivity_case5:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case5();
  ~UpdateArrivalActivity_case5();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case5Activity

class UpdateArrivalActivity_case6:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case6();
  ~UpdateArrivalActivity_case6();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case6Activity

class UpdateArrivalActivity_case7:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case7();
  ~UpdateArrivalActivity_case7();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case7Activity

class UpdateArrivalActivity_case8:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case8();
  ~UpdateArrivalActivity_case8();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case8Activity

class UpdateArrivalActivity_case9:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case9();
  ~UpdateArrivalActivity_case9();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case9Activity

class UpdateArrivalActivity_case10:public Activity {
public:

  Place* NumAggregationLevels;
  short* NumAggregationLevels_Mobius_Mark;
  Place* QueueSize;
  short* QueueSize_Mobius_Mark;

  double* TheDistributionParameters;
  UpdateArrivalActivity_case10();
  ~UpdateArrivalActivity_case10();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // UpdateArrivalActivity_case10Activity

  //List of user-specified place names
  Place* NumAggregationLevels;
  Place* QueueSize;

  // Create instances of all actvities
  UpdateProcessingActivity UpdateProcessing;
  UpdateArrivalActivity_case1 UpdateArrival_case1;
  UpdateArrivalActivity_case2 UpdateArrival_case2;
  UpdateArrivalActivity_case3 UpdateArrival_case3;
  UpdateArrivalActivity_case4 UpdateArrival_case4;
  UpdateArrivalActivity_case5 UpdateArrival_case5;
  UpdateArrivalActivity_case6 UpdateArrival_case6;
  UpdateArrivalActivity_case7 UpdateArrival_case7;
  UpdateArrivalActivity_case8 UpdateArrival_case8;
  UpdateArrivalActivity_case9 UpdateArrival_case9;
  UpdateArrivalActivity_case10 UpdateArrival_case10;
  //Create instances of all groups 
  EmptyGroup ImmediateGroup;
  PostselectGroup UpdateArrivalGroup;
  incidentSAN();
  ~incidentSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end incidentSAN

#endif // incidentSAN_H_
