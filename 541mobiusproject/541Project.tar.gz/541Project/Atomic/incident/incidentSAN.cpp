

// This C++ file was created by SanEditor

#include "Atomic/incident/incidentSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         incidentSAN Constructor             
******************************************************************/


incidentSAN::incidentSAN(){


  UpdateArrivalGroup.initialize(10, "UpdateArrivalGroup");
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case1);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case2);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case3);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case4);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case5);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case6);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case7);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case8);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case9);
  UpdateArrivalGroup.appendGroup((BaseGroupClass*) &UpdateArrival_case10);

  Activity* InitialActionList[11]={
    &UpdateProcessing, //0
    &UpdateArrival_case1, //1
    &UpdateArrival_case2, //2
    &UpdateArrival_case3, //3
    &UpdateArrival_case4, //4
    &UpdateArrival_case5, //5
    &UpdateArrival_case6, //6
    &UpdateArrival_case7, //7
    &UpdateArrival_case8, //8
    &UpdateArrival_case9, //9
    &UpdateArrival_case10  // 10
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(UpdateProcessing), 
    (BaseGroupClass*) &(UpdateArrivalGroup)
  };

  NumAggregationLevels = new Place("NumAggregationLevels" ,0);
  QueueSize = new Place("QueueSize" ,0);
  BaseStateVariableClass* InitialPlaces[2]={
    NumAggregationLevels,  // 0
    QueueSize   // 1
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("incident", 2, InitialPlaces, 
                        0, InitialROPlaces, 
                        11, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[21][2]={ 
    {1,0}, {0,1}, {1,1}, {0,2}, {1,2}, {0,3}, {1,3}, {0,4}, {1,4}, 
    {0,5}, {1,5}, {0,6}, {1,6}, {0,7}, {1,7}, {0,8}, {1,8}, {0,9}, 
    {1,9}, {0,10}, {1,10}
  };
  for(int n=0;n<21;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[1][2]={ 
    {1,0}
  };
  for(int n=0;n<1;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<11;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void incidentSAN::CustomInitialization() {

}
incidentSAN::~incidentSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void incidentSAN::assignPlacesToActivitiesInst(){
}
void incidentSAN::assignPlacesToActivitiesTimed(){
  UpdateProcessing.QueueSize = (Place*) LocalStateVariables[1];
  UpdateProcessing.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case1.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case1.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case2.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case2.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case3.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case3.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case4.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case4.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case5.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case5.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case6.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case6.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case7.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case7.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case8.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case8.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case9.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case9.QueueSize = (Place*) LocalStateVariables[1];
  UpdateArrival_case10.NumAggregationLevels = (Place*) LocalStateVariables[0];
  UpdateArrival_case10.QueueSize = (Place*) LocalStateVariables[1];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================UpdateProcessingActivity========================*/

incidentSAN::UpdateProcessingActivity::UpdateProcessingActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateProcessing",0,Exponential, RaceEnabled, 1,1, false);
}

incidentSAN::UpdateProcessingActivity::~UpdateProcessingActivity(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateProcessingActivity::LinkVariables(){
  QueueSize->Register(&QueueSize_Mobius_Mark);
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
}

bool incidentSAN::UpdateProcessingActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((Process_GateIP()));
  return NewEnabled;
}

    bool incidentSAN::UpdateProcessingActivity::Process_GateIP(){
if (QueueSize->Mark() > 0)
{
  return 1;
}
else
{
  return 0;
}
return 0;
    }

double incidentSAN::UpdateProcessingActivity::Rate(){
  return 1/(NumAggregationLevels->Mark() * CostPerLevel);
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateProcessingActivity::Weight(){ 
  return 1;
}

bool incidentSAN::UpdateProcessingActivity::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateProcessingActivity::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateProcessingActivity::SampleDistribution(){
  return TheDistribution->Exponential(1/(NumAggregationLevels->Mark() * CostPerLevel));
}

double* incidentSAN::UpdateProcessingActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateProcessingActivity::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateProcessingActivity::Fire(){
  QueueSize->Mark() --;
  return this;
}

/*======================UpdateArrivalActivity_case1========================*/

incidentSAN::UpdateArrivalActivity_case1::UpdateArrivalActivity_case1(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case1",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case1::~UpdateArrivalActivity_case1(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case1::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case1::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case1::Weight(){ 
  if  (DistributionSlope * 1 + DistributionIntercept > 0)
{
  return DistributionSlope * 1 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case1::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case1::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case1::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case1::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case1::Fire(){
  NumAggregationLevels->Mark() =  1;

if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case2========================*/

incidentSAN::UpdateArrivalActivity_case2::UpdateArrivalActivity_case2(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case2",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case2::~UpdateArrivalActivity_case2(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case2::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case2::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case2::Weight(){ 
  if  (DistributionSlope * 2 + DistributionIntercept > 0)
{
  return DistributionSlope * 2 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case2::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case2::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case2::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case2::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case2::Fire(){
  NumAggregationLevels->Mark() =  2;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case3========================*/

incidentSAN::UpdateArrivalActivity_case3::UpdateArrivalActivity_case3(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case3",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case3::~UpdateArrivalActivity_case3(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case3::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case3::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case3::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case3::Weight(){ 
  if  (DistributionSlope * 3 + DistributionIntercept > 0)
{
  return DistributionSlope * 3 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case3::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case3::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case3::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case3::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case3::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case3::Fire(){
  NumAggregationLevels->Mark() =  3;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case4========================*/

incidentSAN::UpdateArrivalActivity_case4::UpdateArrivalActivity_case4(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case4",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case4::~UpdateArrivalActivity_case4(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case4::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case4::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case4::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case4::Weight(){ 
  if  (DistributionSlope * 4 + DistributionIntercept > 0)
{
  return DistributionSlope * 4 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case4::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case4::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case4::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case4::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case4::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case4::Fire(){
  NumAggregationLevels->Mark() =  4;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case5========================*/

incidentSAN::UpdateArrivalActivity_case5::UpdateArrivalActivity_case5(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case5",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case5::~UpdateArrivalActivity_case5(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case5::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case5::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case5::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case5::Weight(){ 
  if  (DistributionSlope * 5 + DistributionIntercept > 0)
{
  return DistributionSlope * 5 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case5::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case5::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case5::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case5::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case5::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case5::Fire(){
  NumAggregationLevels->Mark() =  5;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case6========================*/

incidentSAN::UpdateArrivalActivity_case6::UpdateArrivalActivity_case6(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case6",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case6::~UpdateArrivalActivity_case6(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case6::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case6::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case6::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case6::Weight(){ 
  if  (DistributionSlope * 6 + DistributionIntercept > 0)
{
  return DistributionSlope * 6 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case6::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case6::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case6::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case6::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case6::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case6::Fire(){
  NumAggregationLevels->Mark() =  6;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case7========================*/

incidentSAN::UpdateArrivalActivity_case7::UpdateArrivalActivity_case7(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case7",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case7::~UpdateArrivalActivity_case7(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case7::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case7::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case7::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case7::Weight(){ 
  if  (DistributionSlope * 7 + DistributionIntercept > 0)
{
  return DistributionSlope * 7 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case7::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case7::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case7::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case7::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case7::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case7::Fire(){
  NumAggregationLevels->Mark() =  7;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case8========================*/

incidentSAN::UpdateArrivalActivity_case8::UpdateArrivalActivity_case8(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case8",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case8::~UpdateArrivalActivity_case8(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case8::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case8::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case8::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case8::Weight(){ 
  if  (DistributionSlope * 8 + DistributionIntercept > 0)
{
  return DistributionSlope * 8 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case8::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case8::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case8::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case8::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case8::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case8::Fire(){
  NumAggregationLevels->Mark() =  8;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case9========================*/

incidentSAN::UpdateArrivalActivity_case9::UpdateArrivalActivity_case9(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case9",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case9::~UpdateArrivalActivity_case9(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case9::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case9::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case9::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case9::Weight(){ 
  if  (DistributionSlope * 9 + DistributionIntercept > 0)
{
  return DistributionSlope * 9 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case9::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case9::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case9::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case9::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case9::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case9::Fire(){
  NumAggregationLevels->Mark() =  9;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

/*======================UpdateArrivalActivity_case10========================*/

incidentSAN::UpdateArrivalActivity_case10::UpdateArrivalActivity_case10(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("UpdateArrival_case10",1,Exponential, RaceEnabled, 2,0, false);
}

incidentSAN::UpdateArrivalActivity_case10::~UpdateArrivalActivity_case10(){
  delete[] TheDistributionParameters;
}

void incidentSAN::UpdateArrivalActivity_case10::LinkVariables(){
  NumAggregationLevels->Register(&NumAggregationLevels_Mobius_Mark);
  QueueSize->Register(&QueueSize_Mobius_Mark);
}

bool incidentSAN::UpdateArrivalActivity_case10::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double incidentSAN::UpdateArrivalActivity_case10::Rate(){
  return ArrivalRate;
  return 1.0;  // default rate if none is specified
}

double incidentSAN::UpdateArrivalActivity_case10::Weight(){ 
  if  (DistributionSlope * 10 + DistributionIntercept > 0)
{
  return DistributionSlope * 10 + DistributionIntercept;
}
else
{
  return 0;
}
}

bool incidentSAN::UpdateArrivalActivity_case10::ReactivationPredicate(){ 
  return false;
}

bool incidentSAN::UpdateArrivalActivity_case10::ReactivationFunction(){ 
  return false;
}

double incidentSAN::UpdateArrivalActivity_case10::SampleDistribution(){
  return TheDistribution->Exponential(ArrivalRate);
}

double* incidentSAN::UpdateArrivalActivity_case10::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int incidentSAN::UpdateArrivalActivity_case10::Rank(){
  return 1;
}

BaseActionClass* incidentSAN::UpdateArrivalActivity_case10::Fire(){
  NumAggregationLevels->Mark() =  10;


if (QueueSize->Mark() < MaxQueueSize)
{
  QueueSize->Mark() ++;
}
  return this;
}

