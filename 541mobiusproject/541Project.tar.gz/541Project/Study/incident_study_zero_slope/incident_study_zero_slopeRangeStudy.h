
#ifndef incident_study_zero_slopeRangeSTUDY_H_
#define incident_study_zero_slopeRangeSTUDY_H_

#include "Reward/incident_rewards/incident_rewardsPVNodes.h"
#include "Reward/incident_rewards/incident_rewardsPVModel.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern double ArrivalRate;
extern double CostPerLevel;
extern double DistributionIntercept;
extern double DistributionSlope;
extern short MaxQueueSize;

class incident_study_zero_slopeRangeStudy : public BaseStudyClass {
public:

incident_study_zero_slopeRangeStudy();
~incident_study_zero_slopeRangeStudy();

private:

double *ArrivalRateValues;
double *CostPerLevelValues;
double *DistributionInterceptValues;
double *DistributionSlopeValues;
short *MaxQueueSizeValues;

void SetValues_ArrivalRate();
void SetValues_CostPerLevel();
void SetValues_DistributionIntercept();
void SetValues_DistributionSlope();
void SetValues_MaxQueueSize();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

