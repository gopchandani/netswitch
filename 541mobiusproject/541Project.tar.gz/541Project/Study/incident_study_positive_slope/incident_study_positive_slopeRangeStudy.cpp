
#include "Study/incident_study_positive_slope/incident_study_positive_slopeRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
double ArrivalRate;
double CostPerLevel;
double DistributionIntercept;
double DistributionSlope;
short MaxQueueSize;

//********************************************************
//incident_study_positive_slopeRangeStudy Constructor
//********************************************************
incident_study_positive_slopeRangeStudy::incident_study_positive_slopeRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 5;
  NumExps = 49;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("ArrivalRate");
  GVTypes[0]=strdup("double");
  GVNames[1]=strdup("CostPerLevel");
  GVTypes[1]=strdup("double");
  GVNames[2]=strdup("DistributionIntercept");
  GVTypes[2]=strdup("double");
  GVNames[3]=strdup("DistributionSlope");
  GVTypes[3]=strdup("double");
  GVNames[4]=strdup("MaxQueueSize");
  GVTypes[4]=strdup("short");

  // create the arrays to store the values of each gv
  ArrivalRateValues = new double[NumExps];
  CostPerLevelValues = new double[NumExps];
  DistributionInterceptValues = new double[NumExps];
  DistributionSlopeValues = new double[NumExps];
  MaxQueueSizeValues = new short[NumExps];

  // call methods to assign values to each gv
  SetValues_ArrivalRate();
  SetValues_CostPerLevel();
  SetValues_DistributionIntercept();
  SetValues_DistributionSlope();
  SetValues_MaxQueueSize();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//incident_study_positive_slopeRangeStudy Destructor
//******************************************************
incident_study_positive_slopeRangeStudy::~incident_study_positive_slopeRangeStudy() {
  delete [] ArrivalRateValues;
  delete [] CostPerLevelValues;
  delete [] DistributionInterceptValues;
  delete [] DistributionSlopeValues;
  delete [] MaxQueueSizeValues;
  delete ThePVModel;
}


//******************************************************
// set values for ArrivalRate
//******************************************************
void incident_study_positive_slopeRangeStudy::SetValues_ArrivalRate() {
  for (int n=0; n<NumExps; n++)
    ArrivalRateValues[n] = 0.1;
}


//******************************************************
// set values for CostPerLevel
//******************************************************
void incident_study_positive_slopeRangeStudy::SetValues_CostPerLevel() {
  CostPerLevelValues[0] = 0.2;
  CostPerLevelValues[1] = 0.30000000000000004;
  CostPerLevelValues[2] = 0.4;
  CostPerLevelValues[3] = 0.5;
  CostPerLevelValues[4] = 0.6;
  CostPerLevelValues[5] = 0.7;
  CostPerLevelValues[6] = 0.7999999999999999;
  CostPerLevelValues[7] = 0.8999999999999999;
  CostPerLevelValues[8] = 0.9999999999999999;
  CostPerLevelValues[9] = 1.0999999999999999;
  CostPerLevelValues[10] = 1.2;
  CostPerLevelValues[11] = 1.3;
  CostPerLevelValues[12] = 1.4000000000000001;
  CostPerLevelValues[13] = 1.5000000000000002;
  CostPerLevelValues[14] = 1.6000000000000003;
  CostPerLevelValues[15] = 1.7000000000000004;
  CostPerLevelValues[16] = 1.8000000000000005;
  CostPerLevelValues[17] = 1.9000000000000006;
  CostPerLevelValues[18] = 2.0000000000000004;
  CostPerLevelValues[19] = 2.1000000000000005;
  CostPerLevelValues[20] = 2.2000000000000006;
  CostPerLevelValues[21] = 2.3000000000000007;
  CostPerLevelValues[22] = 2.400000000000001;
  CostPerLevelValues[23] = 2.500000000000001;
  CostPerLevelValues[24] = 2.600000000000001;
  CostPerLevelValues[25] = 2.700000000000001;
  CostPerLevelValues[26] = 2.800000000000001;
  CostPerLevelValues[27] = 2.9000000000000012;
  CostPerLevelValues[28] = 3.0000000000000013;
  CostPerLevelValues[29] = 3.1000000000000014;
  CostPerLevelValues[30] = 3.2000000000000015;
  CostPerLevelValues[31] = 3.3000000000000016;
  CostPerLevelValues[32] = 3.4000000000000017;
  CostPerLevelValues[33] = 3.5000000000000018;
  CostPerLevelValues[34] = 3.600000000000002;
  CostPerLevelValues[35] = 3.700000000000002;
  CostPerLevelValues[36] = 3.800000000000002;
  CostPerLevelValues[37] = 3.900000000000002;
  CostPerLevelValues[38] = 4.000000000000002;
  CostPerLevelValues[39] = 4.100000000000001;
  CostPerLevelValues[40] = 4.200000000000001;
  CostPerLevelValues[41] = 4.300000000000001;
  CostPerLevelValues[42] = 4.4;
  CostPerLevelValues[43] = 4.5;
  CostPerLevelValues[44] = 4.6;
  CostPerLevelValues[45] = 4.699999999999999;
  CostPerLevelValues[46] = 4.799999999999999;
  CostPerLevelValues[47] = 4.899999999999999;
  CostPerLevelValues[48] = 4.999999999999998;
}


//******************************************************
// set values for DistributionIntercept
//******************************************************
void incident_study_positive_slopeRangeStudy::SetValues_DistributionIntercept() {
  for (int n=0; n<NumExps; n++)
    DistributionInterceptValues[n] = 5.0;
}


//******************************************************
// set values for DistributionSlope
//******************************************************
void incident_study_positive_slopeRangeStudy::SetValues_DistributionSlope() {
  for (int n=0; n<NumExps; n++)
    DistributionSlopeValues[n] = 1.0;
}


//******************************************************
// set values for MaxQueueSize
//******************************************************
void incident_study_positive_slopeRangeStudy::SetValues_MaxQueueSize() {
  for (int n=0; n<NumExps; n++)
    MaxQueueSizeValues[n] = 100;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void incident_study_positive_slopeRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "ArrivalRate\tdouble\t" << ArrivalRate << endl;
  cout << "CostPerLevel\tdouble\t" << CostPerLevel << endl;
  cout << "DistributionIntercept\tdouble\t" << DistributionIntercept << endl;
  cout << "DistributionSlope\tdouble\t" << DistributionSlope << endl;
  cout << "MaxQueueSize\tshort\t" << MaxQueueSize << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *incident_study_positive_slopeRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("ArrivalRate", TheGVName) == 0)
    return &ArrivalRate;
  else if (strcmp("CostPerLevel", TheGVName) == 0)
    return &CostPerLevel;
  else if (strcmp("DistributionIntercept", TheGVName) == 0)
    return &DistributionIntercept;
  else if (strcmp("DistributionSlope", TheGVName) == 0)
    return &DistributionSlope;
  else if (strcmp("MaxQueueSize", TheGVName) == 0)
    return &MaxQueueSize;
  else 
    cerr<<"!! incident_study_positive_slopeRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void incident_study_positive_slopeRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("ArrivalRate", TheGVName) == 0)
    ArrivalRate = *(double *)TheGVValue;
  else if (strcmp("CostPerLevel", TheGVName) == 0)
    CostPerLevel = *(double *)TheGVValue;
  else if (strcmp("DistributionIntercept", TheGVName) == 0)
    DistributionIntercept = *(double *)TheGVValue;
  else if (strcmp("DistributionSlope", TheGVName) == 0)
    DistributionSlope = *(double *)TheGVValue;
  else if (strcmp("MaxQueueSize", TheGVName) == 0)
    MaxQueueSize = *(short *)TheGVValue;
  else 
    cerr<<"!! incident_study_positive_slopeRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void incident_study_positive_slopeRangeStudy::SetGVs(int expNum) {
  ArrivalRate = ArrivalRateValues[expNum];
  CostPerLevel = CostPerLevelValues[expNum];
  DistributionIntercept = DistributionInterceptValues[expNum];
  DistributionSlope = DistributionSlopeValues[expNum];
  MaxQueueSize = MaxQueueSizeValues[expNum];
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new incident_study_positive_slopeRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* incident_study_positive_slopeRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new incident_rewardsPVModel(expandTimeArrays);
  return ThePVModel;
}


