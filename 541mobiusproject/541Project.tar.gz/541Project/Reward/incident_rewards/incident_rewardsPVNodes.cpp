#include "incident_rewardsPVNodes.h"

incident_rewardsPV0Worker::incident_rewardsPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&incident);
}

incident_rewardsPV0Worker::~incident_rewardsPV0Worker() {
  delete [] TheModelPtr;
}

double incident_rewardsPV0Worker::Reward_Function(void) {

return incident->QueueSize->Mark();

return (0);



}

incident_rewardsPV0::incident_rewardsPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheincidentSAN);
  double startpts[1]={0.0};
  double stoppts[1]={0.0+1.0};
  Initialize("AvgQueueSize",(RewardType)3,1, startpts, stoppts, timeindex, 0,1, 1);
  Type = steady_state;
  AddVariableDependency("QueueSize","incident");
}

incident_rewardsPV0::~incident_rewardsPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void incident_rewardsPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new incident_rewardsPV0Worker;
}
incident_rewardsPV1Worker::incident_rewardsPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&incident);
}

incident_rewardsPV1Worker::~incident_rewardsPV1Worker() {
  delete [] TheModelPtr;
}

double incident_rewardsPV1Worker::Reward_Function(void) {

return incident->NumAggregationLevels->Mark();

return (0);



}

incident_rewardsPV1::incident_rewardsPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheincidentSAN);
  double startpts[1]={0.0};
  double stoppts[1]={0.0+1.0};
  Initialize("AvgPeerDistance",(RewardType)3,1, startpts, stoppts, timeindex, 0,1, 1);
  Type = steady_state;
  AddVariableDependency("NumAggregationLevels","incident");
}

incident_rewardsPV1::~incident_rewardsPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void incident_rewardsPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new incident_rewardsPV1Worker;
}
incident_rewardsPV2Worker::incident_rewardsPV2Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&incident);
}

incident_rewardsPV2Worker::~incident_rewardsPV2Worker() {
  delete [] TheModelPtr;
}

double incident_rewardsPV2Worker::Reward_Function(void) {

if (incident->QueueSize->Mark() >= MaxQueueSize)
{
  return 1;
}
else
{
  return 0;
}

return (0);



}

incident_rewardsPV2::incident_rewardsPV2(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheincidentSAN);
  double startpts[1]={0.0};
  double stoppts[1]={0.0+1.0};
  Initialize("BlockingProbability",(RewardType)3,1, startpts, stoppts, timeindex, 0,1, 1);
  Type = steady_state;
  AddVariableDependency("QueueSize","incident");
}

incident_rewardsPV2::~incident_rewardsPV2() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void incident_rewardsPV2::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new incident_rewardsPV2Worker;
}
