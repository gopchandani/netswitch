#include "incident_rewardsPVModel.h"

incident_rewardsPVModel::incident_rewardsPVModel(bool expandTimeArrays) {
  TheModel=new incidentSAN();
  DefineName("incident_rewardsPVModel");
  CreatePVList(3, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* incident_rewardsPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new incident_rewardsPV0(timeindex);
    break;
  case 1:
    return new incident_rewardsPV1(timeindex);
    break;
  case 2:
    return new incident_rewardsPV2(timeindex);
    break;
  }
  return NULL;
}
