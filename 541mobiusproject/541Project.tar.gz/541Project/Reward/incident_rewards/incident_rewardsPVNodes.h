#ifndef _INCIDENT_REWARDS_PVS_
#define _INCIDENT_REWARDS_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Atomic/incident/incidentSAN.h"
#include "Cpp/Performance_Variables/SteadyState.hpp"


class incident_rewardsPV0Worker:public SteadyState
{
 public:
  incidentSAN *incident;
  
  incident_rewardsPV0Worker();
  ~incident_rewardsPV0Worker();
  double Reward_Function();
};

class incident_rewardsPV0:public PerformanceVariableNode
{
 public:
  incidentSAN *TheincidentSAN;

  incident_rewardsPV0Worker *incident_rewardsPV0WorkerList;

  incident_rewardsPV0(int timeindex=0);
  ~incident_rewardsPV0();
  void CreateWorkerList(void);
};

class incident_rewardsPV1Worker:public SteadyState
{
 public:
  incidentSAN *incident;
  
  incident_rewardsPV1Worker();
  ~incident_rewardsPV1Worker();
  double Reward_Function();
};

class incident_rewardsPV1:public PerformanceVariableNode
{
 public:
  incidentSAN *TheincidentSAN;

  incident_rewardsPV1Worker *incident_rewardsPV1WorkerList;

  incident_rewardsPV1(int timeindex=0);
  ~incident_rewardsPV1();
  void CreateWorkerList(void);
};

class incident_rewardsPV2Worker:public SteadyState
{
 public:
  incidentSAN *incident;
  
  incident_rewardsPV2Worker();
  ~incident_rewardsPV2Worker();
  double Reward_Function();
};

class incident_rewardsPV2:public PerformanceVariableNode
{
 public:
  incidentSAN *TheincidentSAN;

  incident_rewardsPV2Worker *incident_rewardsPV2WorkerList;

  incident_rewardsPV2(int timeindex=0);
  ~incident_rewardsPV2();
  void CreateWorkerList(void);
};

#endif
