#ifndef _INCIDENT_REWARDS_PVMODEL_
#define _INCIDENT_REWARDS_PVMODEL_
#include "incident_rewardsPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Atomic/incident/incidentSAN.h"
class incident_rewardsPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  incident_rewardsPVModel(bool expandtimepoints);
};

#endif
